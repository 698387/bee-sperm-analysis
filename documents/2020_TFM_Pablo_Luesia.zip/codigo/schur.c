/* SCHUR

   Author:
   Fulanito
   Student at Universidad de Zaragoza
   Email: xxxx@unizar.es

   A module for doing solving linear systems which are tridiagonal
   using Schur complement method and a dense representation.
*/

// Standard libraries
#include <stdio.h>
#include <stdlib.h>

// Project specific libraries
#include "aux.h"          // access max and min macros
#include "md-sparse.h"
#include "smalloc.h"
#include "precision.h"
#include "md-newton.h"

